Here is a US English translation of all verses in Chapter 2 of the Bhagavad Gita, also known as Samkhya Yoga (The Yoga of Knowledge):

Chapter 2: Contents of the Gita Summarized

Verse 1:
Sanjaya said: To him (Arjuna) who was thus overwhelmed with compassion, with his eyes full of tears and distressed, Madhusudana (Krishna), spoke these words.

Verse 2:
The Supreme Lord said: My dear Arjuna, how has this impurity come upon you in this hour of peril? It is not befitting an honorable person. It leads not to higher planets, but to infamy.

Verse 3:
O son of Pritha, do not yield to this degrading impotence. It does not become you. Give up such petty weakness of heart and arise, O chastiser of the enemy!

Verse 4:
Arjuna said: O Madhusudana, how can I counterattack with arrows in battle men like Bhishma and Drona, who are worthy of my worship, O killer of enemies?

Verse 5:
It would be better to live in this world by begging than to enjoy life by killing these noble elders, who are my teachers. If we kill them, the wealth and pleasures we enjoy will be tainted with blood.

Verse 6:
We do not even know which result of this war is preferable for us—conquering them or being conquered by them. Even after killing them, we would not desire to live. Yet, the sons of Dhritarashtra are standing before us.

Verse 7:
Now I am confused about my duty and have lost all composure because of miserly weakness. In this condition, I am asking You to tell me for certain what is best for me. I am Your disciple, and a soul surrendered unto You. Please instruct me.

Verse 8:
I can find no means to drive away this grief which is drying up my senses. I will not be able to dispel it even if I win a prosperous, unrivaled kingdom on earth with sovereignty like the demigods in heaven.

Verse 9:
Sanjaya said: Having spoken thus to Hrishikesha (Krishna), Gudakesha (Arjuna), the chastiser of enemies, said, "Govinda, I shall not fight," and became silent.

Verse 10:
O descendant of Bharata (Dhritarashtra), then, in the midst of both armies, Hrishikesha (Krishna), smiling as if, spoke these words to the grief-stricken Arjuna.

Verse 11:
The Supreme Lord said: While you speak words of wisdom, you are mourning for that which is not worthy of grief. The wise lament neither for the living nor for the dead.

Verse 12:
Never was there a time when I did not exist, nor you, nor all these kings; nor in the future shall any of us cease to be.

Verse 13:
Just as the embodied soul continuously passes from childhood to youth to old age in this body, similarly, at the time of death, the soul passes into another body. The steady one is not deluded by this.

Verse 14:
O son of Kunti, the nonpermanent appearance of happiness and distress, and their disappearance in due course, are like the appearance and disappearance of winter and summer seasons. They arise from sense perception, O scion of Bharata, and one must learn to tolerate them without being disturbed.

Verse 15:
O best among men (Arjuna), the person who is not disturbed by happiness and distress, and is steady in both, is certainly eligible for liberation.

Verse 16:
Of the transient there is no endurance, and of the eternal there is no cessation. This has verily been observed and concluded by the seers of the truth.

Verse 17:
That which pervades the entire body, know it to be indestructible. No one can cause the destruction of that imperishable being.

Verse 18:
These bodies of the embodied soul, which is eternal, indestructible, and immeasurable, are said to have an end. Therefore, fight, O descendant of Bharata.

Verse 19:
He who considers the living entity the slayer and he who thinks it is slain, neither of them is in knowledge. For the self neither slays nor is slain.

Verse 20:
For the soul there is never birth nor death. He has not come into being, does not come into being, and will not come into being. He is unborn, eternal, ever-existing, and primeval. He is not slain when the body is slain.

Verse 21:
O Partha (Arjuna), how can a person who knows that the soul is indestructible, unborn, eternal, and immutable, kill anyone or cause anyone to kill?

 Verse 22:
As a person puts on new garments, giving up old ones, similarly, the soul accepts new material bodies, giving up the old and useless ones.

Verse 23:
The soul can never be cut into pieces by any weapon, nor can he be burned by fire, nor moistened by water, nor withered by the wind.

 Verse 24:
This individual soul is unbreakable and insoluble and can be neither burned nor dried. He is everlasting, all-pervading, unchangeable, immovable, and eternally the same.

Verse 25:
It is said that the soul is invisible, inconceivable, immutable, and unchangeable. Knowing this, you should not grieve for the body.

Verse 26:
If, however, you think that the soul is perpetually born and always dies, still you have no reason to lament, O mighty-armed.

Verse 27:
For one who has taken his birth, death is certain; and for one who is dead, birth is certain. Therefore, in the unavoidable discharge of your duty, you should not lament.

Verse 28:
All created beings are unmanifest in their beginning, manifest in their interim state, and unmanifest again when annihilated. So what need is there for lamentation?

Verse 29:
Some look on the soul as amazing, some describe him as amazing, and some hear of him as amazing, while others, even after hearing about him, cannot understand him at all.

Verse 30:
O descendant of Bharata, he who dwells in the body can never be slain. Therefore, you need not grieve for any living being.

Verse 31:
Considering your specific duty as a kshatriya (warrior), you should know that there is no better engagement for you than fighting for religious principles. Therefore, there is no need for hesitation.

Verse 32:
O Partha, happy are the kshatriyas to whom such fighting opportunities come unsought, opening for them the doors of the heavenly planets.

Verse 33:
If, however, you do not perform your religious duty of fighting, then you will certainly incur sins for neglecting your duties and thus lose your reputation as a fighter.

 Verse 34:
People will always speak of your infamy, and for a respectable man, dishonor is worse than death.

 Verse 35:
The great generals who have highly esteemed your name and fame will think that you have left the battlefield out of fear only, and thus they will consider you insignificant.

Verse 36:
Your enemies will describe you in many unkind words and scorn your ability. What could be more painful for you?

Verse 37:
O son of Kunti, either you will be killed on the battlefield and attain the heavenly planets, or you will conquer and enjoy the earthly kingdom. Therefore, get up with determination and fight.

Verse 38:
Fight for the sake of fighting, without considering happiness or distress, loss or gain, victory or defeat—and by so doing you shall never incur sin.

Verse 39:
Thus far I have described this knowledge to you through analytical study (Sankhya). Now listen as I explain it in terms of working without fruitive results (Karma Yoga).

Verse 40:
In this endeavor there is no loss or diminution, and a little advancement on this path can protect one from the most fearful type of danger.

Verse 41:
Those who are on this path are resolute in purpose, and their aim is one. O beloved child of the Kurus, the intelligence of those who are irresolute is many-branched.

Verse 42-43:
Men of small knowledge are very much attached to the flowery words of the Vedas, which recommend various fruitive activities for elevation to heavenly planets, resultant good birth, power, and so forth. Being desirous of sense gratification and opulent life, they say that there is nothing more than this.

Verse 44:
In the minds of those who are too attached to sense enjoyment and material opulence, and who are bewildered by such things, the resolute determination for devotional service to the Supreme Lord does not take place.

Verse 45:
The Vedas deal with the subject of the three modes of material nature. O Arjuna, rise above these three modes. Be transcendental to all of them. Be free from all dualities and from all anxieties for gain and safety, and be established in the self.

Verse 46:
All purposes that are served by the small pond can at once be served by the great reservoirs of water. Similarly, all the purposes of the Vedas can be served to one who knows the purpose behind them.

Verse 47:
You have a right to perform your prescribed duty, but you are not entitled to the fruits of action. Never consider yourself the cause of the results of your activities, and never be attached to not performing your duty.

Verse 48:
Be steadfast in yoga, O Arjuna. Perform your duty and abandon all attachment to success or failure. Such evenness of mind is called yoga.

Verse 49:
O Dhananjaya (Arjuna), keep all abominable activities at a great distance by means of this devotional service, and in that consciousness, surrender fully to the Lord. Those who want to enjoy the fruits of their work are misers.

Verse 50:
A man engaged in devotional service rids himself of both good and bad actions even in this life. Therefore strive for yoga, O Arjuna, which is the art of all work.

Verse 51:
By thus engaging in devotional service to the Lord, the wise, engaged in the path of liberation, are freed from the cycle of birth and death by renouncing the fruits of action in the material world, and thus they attain the state beyond all miseries.

Verse 52:
When your intelligence has passed out of the dense forest of delusion, you shall become indifferent to all that has been heard and all that is yet to be heard.

Verse 53:
When your mind is no longer disturbed by the flowery language of the Vedas, and when it remains steady in the trance of self-realization, then you will have attained divine consciousness.

Verse 54:
Arjuna said: O Krishna, what are the symptoms of one whose consciousness is thus merged in transcendence? How does he speak, and what is his language? How does he sit, and how does he walk?

Verse 55:
The Supreme Personality of Godhead said: O Partha, when a man gives up all varieties of desire for sense gratification, which arise from mental concoction, and when his mind, thus purified, finds satisfaction in the self alone, then he is said to be in pure transcendental consciousness.

Verse 56:
One who is not disturbed in mind even amidst the threefold miseries or elated when there is happiness, and who is free from attachment, fear, and anger, is called a sage of steady mind.

Verse 57:
In the material world, one who is unaffected by whatever good or evil he may obtain, neither praising it nor despising it, is firmly fixed in perfect knowledge.

 Verse 58:
One who is able to withdraw his senses from sense objects, as a tortoise draws its limbs into the shell, is firmly fixed in perfect consciousness.

Verse 59:
The embodied soul may be restricted from sense enjoyment, though the desire for sense objects remains. But, ceasing such engagements by experiencing a higher taste, he is fixed in consciousness.

 Verse 60:
The senses are so strong and impetuous, O Arjuna, that they forcibly carry away the mind even of a man of discrimination who is endeavoring to control them.

Verse 61:
One who restrains his senses, keeping them under full control, and fixes his consciousness upon Me, is known as a man of steady intelligence.

Verse 62:
While contemplating the objects of the senses, a person develops attachment for them, and from such attachment lust develops, and from lust anger arises.

 Verse 63:
From anger comes complete delusion, and from delusion comes the bewilderment of memory. When memory is bewildered, intelligence is lost, and when intelligence is lost, one falls down again into the material pool.

Verse 64:
But a person free from all attachment and aversion and able to control his senses through regulative principles of freedom can obtain the complete mercy of the Lord.

 Verse 65:
For one who is thus satisfied in consciousness, the threefold miseries of material existence exist no longer; in such satisfied consciousness, one's intelligence is soon established.

Verse 66:
One who is not connected with the Supreme (in consciousness) can have neither transcendental intelligence nor a steady mind, without which there is no possibility of peace. And how can there be any happiness without peace?

Verse 67:
As a strong wind sweeps away a boat on the water, even one of the wandering senses on which the mind focuses can carry away a man's intelligence.

 Verse 68:
Therefore, O mighty-armed, one whose senses are withdrawn from their objects is certainly of steady intelligence.

 Verse 69:
What is night for all beings is the time of awakening for the self-controlled; and the time of awakening for all beings is night for the introspective sage.

Verse 70:
A person who is not disturbed by the incessant flow of desires—that enter like rivers into the ocean, which is ever being filled but is always still—can alone achieve peace, and not the man who strives to satisfy such desires.

 Verse 71:
A person who has given up all desires for sense gratification, who lives free from desires, who has renounced all sense of proprietorship, and who is devoid of false ego—he alone can attain real peace.

 Verse 72:
That is the way of the spiritual and godly life, after attaining which a man is not bewildered. If one is thus situated even at the hour of death, he can enter into the kingdom of God.

