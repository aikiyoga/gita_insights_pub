Chapter 13: Kshetra Kshetrajna Vibhaga Yoga (The Yoga of the Distinction Between the Field and the Knower of the Field)

Verse 1:
Arjuna said: O Kesava (Krishna), I wish to understand what are prakriti (nature) and purusha (the enjoyer), and what are kshetra (the field) and kshetrajna (the knower of the field). I also wish to know what is true knowledge, and what is the goal of this knowledge?

Verse 2:
The Supreme Divine Lord said: This body is termed as kshetra (the field of activities), O son of Kunti, and the one who knows this body is called kshetrajna (the knower of the field) by the sages who discern the truth about both.

Verse 3:
O scion of Bharata, you should understand that I am also the knower in all bodies. The understanding of this body as the field and the soul and Me as the knower of the field is considered to be true knowledge.

Verse 4:
Now hear from Me in brief about what the field is, what its nature is, how it undergoes changes, from where it is produced, who the knower of the field is, and what his powers are.

Verse 5:
Great sages have described this in various ways in various Vedic hymns, and in the Vedanta-sutra, with sound logic and conclusive evidence.

Verse 6:
The five great elements, false ego, intelligence, the unmanifested, the ten senses and the mind, the five sense objects,

Verse 7:
Desire, hatred, happiness, distress, the aggregate, the life symptoms, and convictions—all these are considered, in summary, to be the field of activities and its interactions.

Verse 8:
Humility; freedom from pride; nonviolence; tolerance; simplicity; approaching a bona fide spiritual master; cleanliness; steadiness; self-control;

Verse 9:
Detachment from the objects of sense gratification; absence of false ego; the perception of the evil of birth, death, old age, and disease;

Verse 10:
Nonattachment to children, wife, home, and the rest; even-mindedness amid pleasant and unpleasant events; and constant and unalloyed devotion to Me—

Verse 11:
Aspiring for an isolated place; detachment from the general populace; accepting the importance of self-realization; and philosophical search for the Absolute Truth—all these I declare to be knowledge, and besides this whatever there may be is ignorance.

Verse 12:
Now I shall explain the object of knowledge, knowing which you will taste the eternal. It is the Brahman, the spirit, beginningless and subordinate to Me, which lies beyond the cause and effect of this material world.

Verse 13:
Everywhere are His hands and legs, His eyes, heads, and faces, and He has ears everywhere. In this way the Supersoul exists, pervading everything in the universe.

Verse 14:
The Supersoul is the original source of all senses, yet He is without senses. He is unattached, although He is the maintainer of all living beings. He transcends the modes of nature, and at the same time He is the master of all modes of material nature.

Verse 15:
The Supreme Truth exists outside and inside of all living beings, the moving and the nonmoving. Because He is subtle, He is beyond the power of the material senses to see or to know. Although far, He is also near to all.

Verse 16:
That Supreme Truth exists as the undivided, but He is situated in the hearts of all living entities as if divided. Although He is the maintainer of every living entity, it is to be understood that He devours and develops all.

Verse 17:
He is the source of light in all luminous objects. He is beyond the darkness of matter and is unmanifested. He is knowledge, the object of knowledge, and the goal of knowledge. He is situated in everyone's heart.

Verse 18:
Thus I have described in summary the field of activities (the body), the knowledge, and the object of knowledge. Only My devotees can understand this thoroughly and thus attain to My nature.

Verse 19:
Material nature and the living entities should be understood to be beginningless. Their transformations and the modes of matter are products of material nature.

Verse 20:
Nature is said to be the cause of all material causes and effects, while the living entity is the cause of the various sufferings and enjoyments in this world.

Verse 21:
The living entity in material nature thus follows the ways of life, enjoying the three modes of nature. This is due to his association with that material nature. Thus he meets with good and evil among various species.

Verse 22:
Yet in this body there is another, a transcendental enjoyer, who is the Lord, the supreme proprietor, and who exists as the overseer and sanctioner, and who is known as the Supersoul.

Verse 23:
One who understands this philosophy concerning material nature, the living entity, and the interaction of the modes of nature is sure to attain liberation. He does not take birth here again, regardless of his present position.

Verse 24:
Some perceive the Supersoul within themselves through meditation, others through the cultivation of knowledge, and still others through working without fruitive desire.

Verse 25:
Again there are those who, although not conversant in spiritual knowledge, begin to worship the Supreme Person upon hearing about Him from others. Because of their tendency to hear from authorities, they also conquer the path of birth and death.

Verse 26:
O best of the Bharatas, know that whatever you see in existence, both moving and nonmoving, is only a combination of the field of activities and the knower of the field.

Verse 27:
One who sees the Supersoul in every living being and who understands that the soul in the material body is never destroyed actually sees.

Verse 28:
One who sees the Supersoul equally present everywhere, in every living being, does not degrade himself by his mind. Thus he approaches the transcendental destination.

Verse 29:
One who can see that all activities are performed by the body, which is created of material nature, and sees that the self does nothing, actually sees.

Verse 30:
When a sensible man ceases to see different identities due to different material bodies and sees how beings are expanded everywhere, he attains the Brahman conception.

Verse 31:
Those who have the eyes of eternity can see that the soul is transcendental, eternal, and beyond the modes of nature. Despite contact with the material body, O Arjuna, the soul neither does anything nor is entangled.

Verse 32:
The sky, due to its subtle nature, does not mix with anything, though it is all-pervading. Similarly, the soul situated in Brahman realization does not mix with the body, though situated in that body.

Verse 33:
O son of Bharata, as the sun alone illuminates all this universe, so does the living entity, the spirit soul, illuminate the entire body by consciousness.

Verse 34:
Those who see with knowledge the difference between the body and the knower of the body and can also understand the process of liberation from bondage in material nature, attain to the supreme goal.

