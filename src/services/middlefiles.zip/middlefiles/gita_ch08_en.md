Chapter 8: Akshara Brahma Yoga (The Yoga of the Imperishable Absolute)

Verse 1:
Arjuna said: O my Lord, O Supreme Person, what is Brahman? What is the self? What is fruitive activity? What is this material manifestation? And what are the demigods? Please explain this to me.

 Verse 2:
Who is the Lord of sacrifice, and how does He live in the body, O Madhusudana? And how can those engaged in devotional service know You at the time of death?

Verse 3:
The Supreme Personality of Godhead said: The indestructible, transcendental living entity is called Brahman, and his eternal nature is called adhyatma, the self. Action pertaining to the development of these material bodies is called karma, or fruitive activities.

 Verse 4:
O best of the embodied beings, the physical nature, which is constantly changing, is called adhibhuta [the material manifestation]. The universal form of the Lord, which includes all the demigods, is called Adhidaiva. And I, who am the Supersoul in the heart of every embodied being, am called Adhiyajna [the Lord of sacrifice].

 Verse 5:
And whoever, at the end of his life, quits his body remembering Me alone at once attains My nature. Of this there is no doubt.

 Verse 6:
Whatever state of being one remembers when he quits his body, O son of Kunti, that state he will attain without fail.

Verse 7:
Therefore, Arjuna, you should always think of Me in the form of Krishna and at the same time carry out your prescribed duty of fighting. With your activities dedicated to Me and your mind and intelligence fixed on Me, you will attain Me without doubt.

Verse 8:
He who meditates on Me as the Supreme Personality of Godhead, his mind constantly engaged in remembering Me, undeviated from the path, he is sure to reach Me, O Partha.

Verse 9:
One should meditate upon the Supreme Person as the one who knows everything, who is the oldest, who is the controller, who is smaller than the smallest, who is the maintainer of everything, who is beyond all material conception, who is inconceivable, and who is always a person. He is luminous like the sun, and being transcendental, He is beyond this material nature.

Verse 10:
One who, at the time of death, fixes his life air between the eyebrows and in full devotion engages his mind in remembering the Supreme Lord, the Personality of Godhead, will certainly attain to the Supreme Personality of Godhead.

Verse 11:
Those who are learned in the Vedas, who utter Omkara and who are great sages in the renounced order enter into Brahman. Desiring such perfection, one practices celibacy. I shall now briefly explain to you this process by which one may attain salvation.

 Verse 12:
The yogic situation is that of detachment from all sensual engagements. Closing all the doors of the senses, the mind confined in the heart and the life air situated at the top of the head, one establishes himself in this yoga.

Verse 13:
After being situated in this yoga practice and vibrating the sacred syllable Om, the supreme combination of letters, if one thinks of the Supreme Personality of Godhead and quits his body, he will certainly reach the spiritual planets.

 Verse 14:
For one who remembers Me without deviation, I am easy to obtain, O son of Pritha, because of his constant engagement in devotional service.

Verse 15:
After attaining Me, the great souls, who are yogis in devotion, never return to this temporary world, which is full of miseries, because they have attained the highest perfection.

Verse 16:
From the highest planet in the material world down to the lowest, all are places of misery wherein repeated birth and death take place. But anyone who comes to My abode, O son of Kunti, never takes birth again.

Verse 17:
By human calculation, a thousand ages taken together constitute the duration of Brahma's one day. And such also is the duration of the night.

Verse 18:
At the beginning of Brahma's day, all living entities become manifest from the unmanifest state, and thereafter, when the night falls, they are merged into the unmanifest again.

 Verse 19:
Again and again, when Brahma's day arrives, this host of living entities comes into being, and with the arrival of Brahma's night, they are helplessly annihilated.

 Verse 20:
Yet there is another unmanifest nature, which is eternal and is transcendental to this manifested and unmanifested matter. It is supreme and is never annihilated. When all in this world is annihilated, that part remains as it is.

Verse 21:
That which the Vedantists describe as unmanifest and infallible, that which is known as the supreme destination, that place from which, having attained it, one never returns—that is My supreme abode.

Verse 22:
The Supreme Personality of Godhead, who is greater than all, is attainable by unalloyed devotion. Although He is present in His abode, He is all-pervading, and everything is situated within Him.

Verse 23:
O best of the Bharatas, I shall now explain to you the different times at which, passing away from this world, the yogi does or does not return.

Verse 24:
Those who know the Supreme Brahman attain that Supreme by passing away from the world during the influence of the fiery god, in the light, at an auspicious moment, during the fortnight of the waxing moon, and during the six months when the sun travels in the north.

 Verse 25:
The mystic who passes away from this world during the smoke, the night, the fortnight of the moon's waning, or the six months when the sun passes to the south reaches the moon planet but again comes back.

 Verse 26:
According to Vedic opinion, there are two ways of passing from this world—one in light and one in darkness. When one passes in light, he does not come back; but when one passes in darkness, he returns.

Verse 27:
Though the devotees know these two paths, O son of Pritha, they are never bewildered. Therefore, be steadfast in your devotion.

Verse 28:
One who accepts the path of devotional service is not bereft of the results derived from studying the Vedas, performing austerities, practicing charity, or pursuing philosophical activities. At the end he reaches the supreme abode.

