Chapter 5: Karma Sanyasa Yoga (The Yoga of Renunciation of Action)

Verse 1:
Arjuna said: O Krishna, You praise the renunciation of actions, and again the performance of action with devotion. Please tell me decisively which of the two is more beneficial.

Verse 2:
The Supreme Lord said: Both the renunciation of actions and the performance of action with devotion lead to the supreme goal. But, of the two, work in devotional service is better than the renunciation of actions.

Verse 3:
One who neither hates nor desires the fruits of his activities is known to be always renounced. Such a person, free from all dualities, easily overcomes material bondage and is completely liberated, O mighty-armed Arjuna.

Verse 4:
Only the ignorant speak of analytical study (Sankhya) and devotional service (Karma Yoga) as different. Those who are truly learned say that by applying oneself well to one of these paths, one achieves the results of both.

Verse 5:
That supreme state which is attained by means of renunciation is also attained by working in devotion. Hence, those who see renunciation and the performance of action with devotion to be identical truly see things as they are.

Verse 6:
Perfect renunciation is difficult to attain without performing work in devotion, O mighty-armed Arjuna, but the sage who is adept in devotional service quickly attains the Supreme.

Verse 7:
One who works in devotion, who is a pure soul, and who controls his mind and senses, is dear to everyone, and everyone is dear to him. Though always working, such a man is never entangled.

Verse 8:
A person in the divine consciousness, although engaged in seeing, hearing, touching, smelling, eating, moving about, sleeping, and breathing—

Verse 9:
Speaking, evacuating, receiving, or opening or closing his eyes—always knows within himself that he actually does nothing at all, for he sees that only the material senses are engaged with their objects.

Verse 10:
One who performs his duty without attachment, surrendering the results unto the Supreme Lord, is unaffected by sinful action, just as a lotus leaf is untouched by water.

Verse 11:
With their body, mind, intelligence, and even their senses, the yogis, abandoning attachment, perform actions only for the purpose of self-purification.

Verse 12:
The steadily devoted soul attains unadulterated peace because he offers the result of all activities to Me; whereas a person who is not in union with the Divine, who is greedy for the fruits of his labor, becomes entangled.

Verse 13:
When the embodied living being controls his nature and mentally renounces all actions, he resides happily in the city of nine gates (the material body), neither working nor causing work to be done.

Verse 14:
The embodied spirit, master of the city of his body, does not create activities, nor does he induce people to act, nor does he create the fruits of action. All this is enacted by the modes of material nature.

Verse 15:
Nor does the Supreme Lord assume anyone's sinful or pious activities. Embodied beings, however, are bewildered because of the ignorance which covers their real knowledge.

Verse 16:
When, however, one is enlightened with the knowledge by which nescience (ignorance) is destroyed, then his knowledge reveals everything, as the sun lights up everything in the daytime.

Verse 17:
When one's intelligence, mind, faith, and refuge are all fixed in the Supreme, then one becomes fully cleansed of misgivings through complete knowledge and thus proceeds straight on the path of liberation.

Verse 18:
The humble sages, by virtue of true knowledge, see with equal vision a learned and gentle brahmana, a cow, an elephant, a dog, and a dog-eater (outcaste).

Verse 19:
Those whose minds are established in sameness and equanimity have already conquered the conditions of birth and death. They are flawless like Brahman and thus are already situated in Brahman.

Verse 20:
A person who neither rejoices upon achieving something pleasant nor laments upon obtaining something unpleasant, who is self-intelligent, unbewildered, and who knows the science of God, is to be understood as already situated in Transcendence.

Verse 21:
With mind unattached to external contacts, he finds happiness in the self. With the mind united with Brahman (the Absolute) in meditation, he enjoys imperishable happiness.

Verse 22:
Indeed, the enjoyments that arise from contact with the material senses are verily the sources of misery, O son of Kunti, for they have a beginning and an end. Therefore, the wise man does not rejoice in them.

Verse 23:
He who is able to tolerate the urges of the material senses and check the force of desire and anger before giving up this body is a yogi and is happy in this world.

Verse 24:
One whose happiness is within, who is active within, who rejoices within and is illumined within, is actually the perfect mystic. He is liberated in the Supreme, and ultimately he attains the Supreme.

Verse 25:
Those who are beyond duality and doubt, whose minds are engaged within, who are always busy working for the welfare of all sentient beings, and who are free from all sins, achieve liberation in the Supreme.

Verse 26:
For those who are free from anger and all material desires, who are self-realized, self-disciplined, and constantly endeavoring for perfection, liberation from material existence is assured both here and hereafter.

Verse 27:
Shutting out all external sense objects, keeping the eyes and vision concentrated between the two eyebrows, equalizing the flow of the incoming and outgoing breaths within the nostrils—

Verse 28:
Thus controlling the mind, senses, and intelligence, the transcendentalist becomes free from desire, fear, and anger and is always in the state of liberation.

Verse 29:
Having realized Me as the enjoyer of all sacrifices and austerities, the Supreme Lord of all the worlds, and the selfless friend of all living beings, My devotee attains peace.

