Here is a US English translation of all verses in Chapter 1 of the Bhagavad Gita, also known as Arjuna Vishada Yoga (The Yoga of Arjuna's Despair):

Chapter 1: Observing the Armies on the Battlefield of Kurukshetra

Verse 1:
Dhritarashtra said: O Sanjaya, assembled on the sacred field of Kurukshetra, eager to fight, what did my sons and the sons of Pandu do?

Verse 2:
Sanjaya said: O King, having seen the army of the Pandavas arrayed in military formation, King Duryodhana approached his teacher Drona and spoke these words:

 Verse 3:
"Behold, O teacher, this mighty army of the sons of Pandu, so expertly arranged by your intelligent disciple, the son of Drupada."

Verse 4:
"Here are heroes, mighty archers, equal in battle to Bhima and Arjuna, like Yuyudhana, Virata, and Drupada, the great chariot fighter."

Verse 5:
"There are also Dhrishtaketu, Chekitana, the valiant King of Kashi, Purujit, Kuntibhoja, and Shaibya, the best of men."

Verse 6:
"There are the strong Yudhamanyu and the brave Uttamaujas, the son of Subhadra, and the sons of Draupadi, all of them great chariot warriors."

Verse 7:
"Know also, O best of the twice-born, about the distinguished warriors on our side, the leaders of my army. I name them for your information."

Verse 8:
"Yourself, Bhishma, Karna, Kripa, who is ever victorious in battle, Ashvatthama, Vikarna, and also the son of Somadatta, Bhurishrava."

Verse 9:
"And many other heroes too, who are ready to give up their lives for my sake. All are well-armed with various weapons and are experienced in military science."

Verse 10:
"Our army, protected by Bhishma, is unlimited, while the army of the Pandavas, protected by Bhima, is limited."

Verse 11:
"Therefore, all of you, remaining in your respective positions in the divisions of the army, must certainly protect Bhishma."

Verse 12:
Then, the mighty grandsire of the Kurus, the glorious patriarch Bhishma, roaring like a lion, loudly blew his conch shell, gladdening Duryodhana.

Verse 13:
After that, conches, kettledrums, bugles, trumpets, and cow horns suddenly blared forth, and the sound was tumultuous.

Verse 14:
Then, Madhava (Krishna) and the son of Pandu (Arjuna), seated in their magnificent chariot yoked with white horses, blew their divine conches.

Verse 15:
Hrishikesha (Krishna) blew his conch, the Panchajanya, Arjuna blew his, the Devadatta, and Bhima, the doer of terrible deeds, blew his great conch, the Paundra.

Verse 16:
King Yudhishthira, the son of Kunti, blew the Anantavijaya, and Nakula and Sahadeva blew the Sughosha and Manipushpaka.

Verse 17:
The King of Kashi, an excellent archer, and Shikhandi, the great chariot fighter, Dhrishtadyumna, Virata, and Satyaki, the unconquerable—

Verse 18:
Drupada, the sons of Draupadi, and the mighty-armed son of Subhadra, O King, all of them blew their respective conches.

Verse 19:
The tumultuous sound vibrated throughout the sky and the earth, and it tore the hearts of the sons of Dhritarashtra.

Verse 20:
Then, seeing the sons of Dhritarashtra arrayed, and the discharge of weapons about to begin, Arjuna, whose ensign was the monkey, took up his bow.

Verse 21:
And, O King, he spoke these words to Hrishikesha (Krishna) in the midst of both armies:

Verse 22:
Arjuna said: O infallible one, please draw my chariot between the two armies so that I may behold those standing here, desiring to fight, and with whom I must contend in this great battle endeavor.

Verse 23:
Let me see those who have come here to fight, wishing to please the evil-minded son of Dhritarashtra.

Verse 24:
Sanjaya said: O descendant of Bharata, thus addressed by Arjuna, Lord Krishna drew up the excellent chariot in the midst of the armies of both parties.

Verse 25:
In front of Bhishma, Drona, and all the rulers of the world, He said: "O Partha (Arjuna), behold these Kurus gathered together."

Verse 26:
There Arjuna saw standing fathers, grandfathers, teachers, maternal uncles, brothers, sons, grandsons, companions, fathers-in-law, and well-wishers in both armies.

Verse 27:
Seeing all these relatives arrayed before him, the son of Kunti, Arjuna, was overwhelmed with great compassion and spoke in sorrow.

Verse 28:
Arjuna said: O Krishna, seeing my kinsmen thus arrayed before me, eager to fight,

Verse 29:
My limbs are failing and my mouth is drying up. My body is trembling, and my hair is standing on end.

Verse 30:
My bow Gandiva is slipping from my hand, and my skin is burning all over. I am unable to stand, and my mind is whirling.

Verse 31:
And I see adverse omens, O Keshava (Krishna). I do not foresee any good by killing my own kinsmen in this battle.

Verse 32:
O Krishna, I do not desire victory, nor kingdom, nor pleasures. Of what use to us is a kingdom, O Govinda (Krishna), or enjoyment, or even life itself?

Verse 33:
Those for whose sake we desire kingdom, enjoyments, and pleasures—they are standing here on the battlefield, having renounced their lives and riches.

Verse 34:
Teachers, fathers, sons, and grandfathers, maternal uncles, fathers-in-law, grandsons, brothers-in-law, and other relatives.

Verse 35:
O Madhusudana (Krishna), I do not wish to kill them, even if they kill me, not even for the dominion over the three worlds, what to speak of the earth.

Verse 36:
What pleasure will be ours, O Janardana (Krishna), by killing these sons of Dhritarashtra? Sin will certainly come upon us if we slay these aggressors.

Verse 37:
Therefore, we should not kill the sons of Dhritarashtra, our relatives. For how can we be happy by killing our own kinsmen, O Madhava (Krishna)?

Verse 38:
Even though they, whose intelligence is overtaken by greed, see no fault in destroying the family or quarreling with friends—

Verse 39:
Why should we, who can see the sin in destroying a family, not turn away from this act, O Janardana?

Verse 40:
With the destruction of the family, the eternal family traditions perish, and thus the rest of the family becomes involved in irreligion.

Verse 41:
O Krishna, when irreligion prevails in the family, the women of the family become corrupted, and from the corruption of women arises unwanted progeny.

Verse 42:
This unwanted progeny leads the family and the destroyers of the family to hell, for their ancestors fall down (from the ability to receive offerings) when the rituals of rice balls and water are stopped.

Verse 43:
By the evil deeds of those who destroy the family tradition and create unwanted progeny, all kinds of community projects and family welfare activities are ruined.

Verse 44:
O Janardana, we have heard by disciplic succession that the residence of those whose family traditions are destroyed is always in hell.

Verse 45:
Alas, how strange it is that we are preparing to commit a great sin, being driven by the desire for the pleasure of kingdom, to kill our own kinsmen.

Verse 46:
Indeed, it would be better for me if the sons of Dhritarashtra, with weapons in hand, kill me in battle, unarmed and unresisting.

Verse 47:
Sanjaya said: Speaking thus on the battlefield, Arjuna cast aside his bow and arrows and sat down on the chariot seat, his mind overwhelmed with grief.

