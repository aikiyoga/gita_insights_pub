Here is a US English translation of all verses in Chapter 4 of the Bhagavad Gita, also known as Jnana Karma Sanyasa Yoga (The Yoga of Knowledge, Action, and Renunciation):

Chapter 4: Jnana Karma Sanyasa Yoga (The Yoga of Knowledge, Action, and Renunciation)

Verse 1:
The Supreme Lord said: I taught this imperishable Yoga to Vivasvan (the sun-god); Vivasvan taught it to Manu (the father of mankind); and Manu in turn instructed it to Ikshvaku.

Verse 2:
This supreme science was thus received through the chain of disciplic succession, and the royal sages understood it in that way. But in the course of time the succession was broken, and therefore the science as it is appears to be lost.

Verse 3:
That same ancient science of the relationship with the Supreme is today told by Me to you because you are My devotee and friend; therefore you can understand the transcendental mystery of this science.

Verse 4:
Arjuna said: You are born after Vivasvan; how am I to understand that You taught this science in the beginning?

Verse 5:
The Supreme Personality of Godhead said: Many, many births both you and I have passed. I can remember all of them, but you cannot, O subduer of the enemy!

Verse 6:
Although I am unborn and My transcendental body never deteriorates, and although I am the Lord of all living entities, I still appear in every millennium in My original transcendental form.

Verse 7:
Whenever and wherever there is a decline in religious practice, O descendant of Bharata, and a predominant rise of irreligion—at that time I descend Myself.

Verse 8:
To deliver the pious and to annihilate the miscreants, as well as to reestablish the principles of religion, I Myself appear, millennium after millennium.

Verse 9:
One who knows the transcendental nature of My appearance and activities does not, upon leaving the body, take his birth again in this material world, but attains My eternal abode, O Arjuna.

Verse 10:
Being freed from attachment, fear, and anger, being fully absorbed in Me, and taking refuge in Me, many persons in the past became purified by knowledge of Me—and thus they all attained transcendental love for Me.

 Verse 11:
As all surrender unto Me, I reward them accordingly. Everyone follows My path in all respects, O son of Pritha.

Verse 12:
Men in this world desire success in fruitive activities, and therefore they worship the demigods. Quickly, of course, results are obtained from fruitive work in this world.

 Verse 13:
According to the three modes of material nature and the work associated with them, the four divisions of human society are created by Me. And although I am the creator of this system, you should know that I am nevertheless the non-doer, being immutable.

Verse 14:
There is no work that affects Me, nor do I aspire for the fruits of action. One who understands this truth about Me also does not become entangled in the fruitive reactions of work.

 Verse 15:
All the liberated souls in ancient times acted with this understanding of My transcendental nature and were therefore free from the bondage of fruitive activities. Therefore, you should perform your duty, following in the footsteps of the ancients, who attained liberation.

Verse 16:
Even the intelligent are bewildered in determining what is action and what is inaction. Now I shall explain to you what action is, knowing which you will be liberated from all misfortune.

Verse 17:
The intricacies of action are very hard to understand. Therefore, one should properly understand what action is, what forbidden action is, and what inaction is.

 Verse 18:
One who sees inaction in action and action in inaction is intelligent among men, and he is in the transcendental position, although engaged in all sorts of activities.

Verse 19:
One is understood to be in full knowledge whose every endeavor is devoid of desire for sense gratification. He is said by sages to be a worker whose fruits of work have been burned up by the fire of perfect knowledge.

Verse 20:
Abandoning all results of his activities, ever satisfied and independent of all possessions, he does not perform any fruitive action, although engaged in all kinds of undertakings.

Verse 21:
Such a man of understanding acts with his mind and intelligence perfectly controlled, gives up all sense of proprietorship over his possessions, and acts only for the bare necessities of life. Thus, he is not affected by sinful reactions.

 Verse 22:
He who is satisfied with gain which comes of its own accord, who is free from duality and does not envy, who is steady in both success and failure, is never entangled, although performing actions.

Verse 23:
The work of a man who is unattached to the modes of material nature and who is fully situated in transcendental knowledge, whose every action is a sacrifice, is completely merged into transcendence.

Verse 24:
For one who is completely absorbed in consciousness of the Divine, the offering, the act of offering, the offered ingredient, the offerer, and the result are all the Supreme.

Verse 25:
Some yogis perfectly worship the demigods by offering different sacrifices to them, and some offer sacrifices in the fire of the Supreme Brahman.

 Verse 26:
Some (the controlled brahmacharis) sacrifice the hearing process and the senses in the fire of mental control, and others (those in household life) sacrifice the objects of the senses, such as sound, in the fire of the senses.

Verse 27:
Those who are interested in self-realization, in terms of mind and sense control, offer the functions of all the senses and the vital force (breath) as oblations into the fire of the controlled mind.

Verse 28:
There are others, who are enlightened by sacrificing their material possessions in severe austerities, by practicing yoga, or by studying the Vedas with great austerity to advance in transcendental knowledge.

Verse 29:
Still others, who are inclined to the process of breath control to remain in trance, practice by offering the outgoing breath into the incoming, and the incoming breath into the outgoing, and thus they remain in trance, stopping all breathing.

Verse 30:
Having controlled the senses, mind, and intelligence, the yogi aims for liberation from material entanglement. He practices sacrificing the senses in the fire of austerity, and some offer all their senses and life force as oblations into the fire of yoga, being controlled in mind and senses.

Verse 31:
O best of the Kuru dynasty, all these performers who know the meaning of sacrifice become cleansed of sinful reactions, and, having tasted the nectar of the results of sacrifices, they advance towards the supreme eternal atmosphere.

Verse 32:
All these different types of sacrifice are approved by the Vedas, and all of them are born of action. Knowing them as such, you will become liberated.

Verse 33:
O chastiser of the enemy, the sacrifice performed in knowledge is better than the mere sacrifice of material possessions. O son of Pritha, after all, all sacrifices of work culminate in transcendental knowledge.

 Verse 34:
Just try to learn the truth by approaching a spiritual master. Inquire from him submissively and render service unto him. The self-realized souls can impart knowledge unto you because they have seen the truth.

Verse 35:
Having obtained true knowledge from a self-realized soul, you will never fall again into such illusion, for by this knowledge you will see that all living beings are but a part of the Supreme, or, in other words, that they are Mine.

 Verse 36:
Even if you are considered to be the most sinful of all sinners, when you are situated in the boat of transcendental knowledge, you will be able to cross over the ocean of miseries.

Verse 37:
As a blazing fire turns firewood to ashes, O Arjuna, so does the fire of knowledge burn to ashes all reactions to material activities.

Verse 38:
In this world, there is nothing so sublime and pure as transcendental knowledge. Such knowledge is the mature fruit of all mysticism. And one who has become accomplished in the practice of yoga enjoys this knowledge within himself in due course of time.

Verse 39:
A faithful man who is dedicated to transcendental knowledge and who subdues his senses is eligible to achieve such knowledge, and having achieved it, he quickly attains the supreme spiritual peace.

Verse 40:
But ignorant and faithless persons who doubt the revealed scriptures do not attain God consciousness; they fall down. For the doubting soul there is neither happiness in this world nor in the next.

Verse 41:
One who has renounced the fruits of action by performing his duty, whose doubts have been destroyed by transcendental knowledge, and who is firmly situated in the self, is not bound by action, O conqueror of riches (Arjuna).

Verse 42:
Therefore, with the weapon of knowledge born of transcendental relation with the Supreme, O Bharata, cut off the doubts from your heart generated by ignorance. Armed with yoga, O conqueror of riches, stand up and fight.
