Chapter 11: Vishvarupa Darshana Yoga (The Yoga of the Vision of the Universal Form)

Verse 1:
Arjuna said: Having heard the supremely confidential spiritual knowledge, which You have revealed out of compassion for me, my illusion is now dispelled.

Verse 2:
O Lotus-eyed one, I have heard from You in detail about the appearance and disappearance of all living beings, and also about Your inexhaustible greatness.

Verse 3:
O Supreme Lord, You are precisely what You declare Yourself to be. Now I desire to see Your divine cosmic form, O greatest of persons.

Verse 4:
O Lord of all mystic power, if You think that I am able to behold it, then kindly show me that imperishable Self of Yours.

Verse 5:
The Supreme Lord said: Behold, O son of Pritha, My hundreds and thousands of divine forms, of various colors and shapes.

Verse 6:
O best of the Bharatas, behold the Adityas, the Vasus, the Rudras, the Ashwini-kumaras, and the Maruts. Behold many wonders never before revealed.

Verse 7:
O Arjuna, behold now in My body the entire universe, with everything moving and nonmoving, assembled together in one place, and whatever else you desire to see.

Verse 8:
But you cannot see Me with your present eyes. Therefore, I give you divine eyes to behold My majestic opulence.

Verse 9:
Sanjaya said: O King, having spoken thus, the Supreme Lord of yoga, Hari (Krishna), showed Arjuna His supreme form as the Lord.

Verse 10-11:
Arjuna saw in that universal form unlimited mouths and eyes, with many wondrous sights. The form was decorated with many celestial ornaments and bore many divine weapons. He wore celestial garlands and garments, and many divine fragrances were anointed over His body. All was astounding, luminous, unlimited, and all-expanding.

Verse 12:
If a thousand suns were to blaze forth simultaneously in the sky, their radiance might resemble the splendor of that mighty being.

Verse 13:
There, in the body of the God of gods, Arjuna then saw the entire universe, with its many divisions, all situated in one place.

Verse 14:
Then, Arjuna, filled with wonder, his hair standing on end, bowed down with folded hands and addressed the Supreme Lord.

Verse 15:
Arjuna said: O my dear Lord Krishna, I see assembled in Your body all the demigods and various other living entities. I see Brahma sitting on the lotus flower, as well as all the great sages and divine serpents.

Verse 16:
O Lord of the universe, O universal form, I see in Your body many arms, bellies, mouths, and eyes, expanded everywhere, without limit. I see in You no end, no middle, and no beginning.

Verse 17:
Your form, adorned with various crowns, clubs, and discuses, is difficult to behold, for it is blazing all around with an effulgence like the sun's, immeasurable and glowing.

Verse 18:
You are the supreme, the ultimate object of knowledge. You are the primeval person, the supreme resting place of this cosmic manifestation. You are the maintainer of the eternal religion, the Personality of Godhead. This is my opinion.

Verse 19:
You are without origin, middle, or end. Your glory is unlimited. You have numberless arms, and the sun and moon are Your eyes. I see You with a blazing fire coming forth from Your mouth, burning this entire universe with Your radiance.

Verse 20:
Although You are one, You are spread throughout the sky and the planets, and all space between. O great one, seeing this wondrous and terrible form, all the planetary systems are disturbed.

Verse 21:
All the hosts of demigods are surrendering before You and entering into You. Some of them, very much afraid, are offering prayers with folded hands. Hosts of great sages and perfected beings are crying "All peace!" and praying to You by chanting the Vedic hymns.

Verse 22:
All the manifestations of Lord Shiva, the Adityas, the Vasus, the Sadhyas, the Vishvadevas, the two Ashvinis, the Maruts, the forefathers, and the Gandharvas, Yakshas, Asuras, and perfected demigods are beholding You in great wonder.

Verse 23:
O mighty-armed one, all the planets with their demigods are disturbed at the sight of Your great form, with its many faces, eyes, arms, thighs, legs, and fearsome teeth; and as they are disturbed, so am I.

Verse 24:
O all-pervading Vishnu, I see You with Your many radiant colors, touching the sky, Your mouths wide open, and Your eyes glowing like the sun. My mind is disturbed by seeing this fearsome form. I lose my equilibrium and cannot stand.

Verse 25:
O Lord of lords, O refuge of the worlds, please be gracious to me. I cannot keep my balance seeing Your blazing deathlike faces and fearsome teeth. In all directions I am bewildered.

Verse 26-27:
All the sons of Dhritarashtra, along with their allied kings, and Bhishma, Drona, Karna, and all our chief warriors are rushing into Your fearful mouths. And some are found sticking in the gaps between Your teeth with their heads crushed.

Verse 28:
As rivers flow into the sea, so all these great warriors are entering Your blazing mouths.

Verse 29:
As moths dash to destruction in a blazing fire, so all these people are rushing into Your mouths with great speed.

Verse 30:
O Vishnu, I see You devouring all people in Your blazing mouths and covering the universe with Your effulgence. Your rays are burning the whole world, O formidable one.

Verse 31:
O Lord of lords, please tell me who You are in this fierce form. I offer my obeisance unto You; please be gracious to me. I want to know about You, for I do not know what Your mission is.

Verse 32:
The Supreme Personality of Godhead said: Time I am, the great destroyer of worlds, and I have come here to annihilate all people. With the exception of you [Pandavas], all the soldiers here on both sides will be slain.

Verse 33:
Therefore, get up and prepare to fight. After conquering your enemies, you will enjoy a flourishing kingdom. They are already put to death by My arrangement, and you, O Savyasachi (Arjuna), can be but an instrument in the fight.

Verse 34:
Drona, Bhishma, Jayadratha, Karna, and the other great warriors present here are already destroyed by Me. Therefore, kill them and do not be disturbed. Fight, and you will vanquish your enemies in battle.

Verse 35:
Sanjaya said: O King, after hearing these words from the Supreme Personality of Godhead, Arjuna trembled, offered obeisance with folded hands, and spoke to Lord Krishna in a faltering voice, greatly fearful.

Verse 36:
Arjuna said: O master of the senses, the world becomes joyful upon hearing Your name, and thus everyone becomes attached to You. The perfected beings offer You respectful obeisances, and the demoniac are afraid, and they flee in all directions. All this is rightly done.

Verse 37:
O great one, greater than Brahma, You are the original creator. Why should they not offer their respectful obeisances unto You? O limitless one, God of gods, refuge of the universe, You are the invincible source of all.

Verse 38:
You are the primeval Lord, the ultimate sanctuary of this cosmic manifestation. You are the knower of everything, and You are all that is knowable. You are the supreme resting place, and You are expanded throughout the entire cosmos, O limitless form!

Verse 39:
You are air, and You are the supreme controller! You are fire, You are water, and You are the moon! You are Brahma, the first living creature, and You are the great-grandfather. Therefore, I offer my respectful obeisances unto You a thousand times, and again and again.

Verse 40:
Obeisance to You from the front, from behind, and from all sides! O unbounded might, You are the master of all potent power. You are all-pervading, and thus You are everything!

Verse 41:
Thinking of You as my friend, I have rashly addressed You "O Krishna," "O Yadava," "O my friend," without knowing Your glories. Please forgive whatever I may have done out of foolishness or love.

Verse 42:
By whatever jest I may have disrespected You in relaxation, in a relationship, sitting together, lying down, or while eating, alone or in front of others—O infallible one, I beg forgiveness for all my offenses.

Verse 43:
You are the father of this complete cosmic manifestation, of the moving and nonmoving. You are the worshipable chief, the supreme spiritual master. No one is greater than You, nor can anyone be equal to You within the three worlds. O Lord of immeasurable might, who is there, then, equal to You?

Verse 44:
You are the original Supreme Personality of Godhead, master of everything and the ultimate rest. Therefore, I fall down to offer You my obeisance and ask for Your mercy. O Lord, please be tolerant with me, as a father with his son, or as a friend with his friend, or as a lover with his beloved.

Verse 45:
After seeing this universal form, which I have never seen before, I am joyful, but at the same time my mind is disturbed with fear. Therefore, O Lord, please bestow Your grace upon me and again show me Your form as the Personality of Godhead, O Lord of lords, O abode of the universe.

Verse 46:
O universal form, O universal soul, please show me Your four-armed form, with the helmet on Your head and with Your four hands holding the club, the wheel, the conchshell, and the lotus flower.

Verse 47:
The Supreme Personality of Godhead said: My dear Arjuna, happily I have shown you, by My internal potency, this universal form within the material world. No one before you has ever seen this unlimited and dazzling form.

Verse 48:
O best of the Kuru dynasty, no one before you has ever seen this universal form of Mine, for neither by studying the Vedas, nor by performing sacrifices, nor by charity, nor by pious activities, nor by severe austerities can I be seen in this form in the material world.

Verse 49:
You have been disturbed at the sight of this horrible feature of Mine. Now let it be finished. My devotee, be free from all disturbance. With a peaceful mind you can now see the form you desire.

Verse 50:
Sanjaya said: When the Personality of Godhead, Krishna, had spoken thus to Arjuna, He displayed His real four-armed form, and at last He showed him His two-armed form, thus encouraging the fearful Arjuna.

Verse 51:
Arjuna said: Seeing this humanlike form, so very beautiful, I am now pacified and restored to my original nature.

Verse 52:
The Supreme Personality of Godhead said: My dear Arjuna, the form which you are now seeing is very difficult to behold. Even the demigods are ever seeking the opportunity to see this form, which is so dear.

Verse 53:
Neither by study of the Vedas, nor by severe austerities, nor by charity, nor by worship can I be seen as you have seen Me.

Verse 54:
My dear Arjuna, only by undivided devotional service can I be understood as I am, standing before you, and can thus be seen directly. Only in this way can you enter into the mysteries of My understanding.

Verse 55:
My dear Arjuna, he who engages in My pure devotional service, free from the contaminations of past activities and mental speculation, who works for Me, who makes Me the supreme goal of his life, and who is friendly to every living being—he certainly comes to Me.
