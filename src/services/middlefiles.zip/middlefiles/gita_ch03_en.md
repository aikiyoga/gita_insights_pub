Here is a US English translation of all verses in Chapter 3 of the Bhagavad Gita, also known as Karma Yoga (The Yoga of Action):

Chapter 3: Karma Yoga (The Yoga of Action)

Verse 1:
Arjuna said: O Janardana, O Keshava, if You consider intelligence to be better than fruitive work, then why do You engage me in this terrible action?

Verse 2:
My intelligence is bewildered by Your seemingly equivocal instructions. Therefore, please tell me decisively one path by which I may attain the highest good.

Verse 3:
The Supreme Personality of Godhead said: O sinless Arjuna, I have already explained that there are two classes of men who try to realize the self. Some are inclined to understand it by empirical, philosophical speculation (the path of knowledge), and others by devotional service (the path of action).

Verse 4:
Not by merely abstaining from action can one achieve freedom from reaction, nor by renunciation alone can one attain perfection.

Verse 5:
Indeed, no one can remain without action even for a moment. All beings are compelled to act helplessly according to the qualities (gunas) born of material nature.

Verse 6:
One who restrains the senses and organs of action but whose mind dwells on sense objects certainly deludes himself and is called a pretender.

Verse 7:
But he who controls the senses by the mind, O Arjuna, and engages his active organs in works of devotion, without attachment, is by far superior.

Verse 8:
Perform your prescribed duty, for action is better than inaction. A man cannot even maintain his physical body without work.

Verse 9:
Work done as a sacrifice for Vishnu has to be performed; otherwise, work causes bondage in this material world. Therefore, O son of Kunti, perform your prescribed duties for His satisfaction, and in that way, you will always remain free from bondage.

Verse 10:
In the beginning of creation, Brahma created mankind along with duties, and said, "Prosper in the performance of these yajnas (sacrifices), for they shall bestow upon you all you wish to achieve."

Verse 11:
By your sacrifices, the celestial gods will be pleased, and by cooperation between humans and the celestial gods, great prosperity will reign for all.

Verse 12:
The celestial gods, being satisfied by the performance of sacrifice, will grant you all the desired necessities of life. But those who enjoy what is given to them without making offerings in return are verily thieves.

Verse 13:
The devotees of the Lord are released from all kinds of sins because they eat food which is offered first for sacrifice. Others, who cook food for personal sense enjoyment, verily eat only sin.

Verse 14:
All living bodies subsist on food grains, which are produced from rains. Rains are produced by performance of yajna (sacrifice), and yajna is born of prescribed duties.

Verse 15:
Regulated activities are prescribed in the Vedas, and the Vedas are directly manifested from the Supreme Personality of Godhead. Consequently, the all-pervading Transcendence is eternally situated in acts of sacrifice.

Verse 16:
My dear Arjuna, one who does not follow this prescribed Vedic system of sacrifice certainly leads a life full of sin, for a person delighting only in the senses lives in vain.

Verse 17:
But for that man who rejoices only in the self, who is illuminated in the self, who rejoices in and is satisfied with the self only, fully satiated—for him there is no duty.

Verse 18:
A self-realized man has no purpose to fulfill in the discharge of his prescribed duties, nor has he any reason not to perform such work. Nor does he depend on any being for any purpose.

Verse 19:
Therefore, without being attached to the fruits of activities, one should act as a matter of duty, for by working without attachment one attains the Supreme.

Verse 20:
Even kings like Janaka and others attained the perfectional stage by performance of prescribed duties. Therefore, just for the sake of educating the people in general, you should perform your work.

Verse 21:
Whatever action a great man performs, common men follow. And whatever standards he sets by exemplary acts, all the world pursues.

Verse 22:
O son of Pritha, there is no work prescribed for Me within all the three planetary systems. Nor am I in want of anything, nor have I a need to obtain anything—and yet I am engaged in prescribed duties.

Verse 23:
For if I ever failed to engage in carefully performing prescribed duties, O Partha, certainly all men would follow My path.

Verse 24:
If I did not perform prescribed duties, all these worlds would be put to ruination. I would be the cause of creating unwanted population, and I would thereby destroy the peace of all living beings.

Verse 25:
As the ignorant perform their duties with attachment to results, the learned may similarly act, but without attachment, for the sake of leading people on the right path.

Verse 26:
So as not to disrupt the minds of ignorant men attached to the fruitive results of prescribed duties, a learned person should not induce them to stop work. Rather, by working in the spirit of devotion, he should engage them in all sorts of activities (for the gradual development of consciousness).

Verse 27:
The spirit soul bewildered by the influence of false ego thinks himself the doer of activities that are in actuality carried out by the three modes of material nature.

Verse 28:
O mighty-armed, one who is in knowledge of the Absolute Truth, O mighty-armed, does not engage himself in the senses and sense gratification, knowing well the differences between work in devotion and work for fruitive results.

Verse 29:
Bewildered by the modes of material nature, the ignorant fully engage themselves in material activities and become attached. But the wise should not unsettle them, although these duties are inferior due to the performers' lack of knowledge.

Verse 30:
Therefore, O Arjuna, surrendering all your works unto Me, with full knowledge of Me, without desires for profit, with no claims to proprietorship, and free from lethargy, fight.

Verse 31:
Those persons who execute their duties according to My injunctions and who follow this teaching faithfully, without envy, become free from the bondage of fruitive actions.

Verse 32:
But those who, out of envy, disregard these teachings and do not practice them regularly, are to be considered bereft of all knowledge, befooled, and ruined in their endeavors for perfection.

Verse 33:
Even a man of knowledge acts according to his own nature, for everyone follows his nature. What can repression accomplish?

Verse 34:
There are principles to regulate attachment and aversion pertaining to the senses and their objects. One should not come under the control of such attachment and aversion, because they are stumbling blocks on the path of self-realization.

Verse 35:
It is far better to discharge one's prescribed duties, even though they may be faultily, than another's duties. Destruction in the course of performing one's own duty is better than engaging in another's duties, for to follow another's path is dangerous.

Verse 36:
Arjuna said: O descendant of Vrishni, by what is one impelled to sinful acts, even unwillingly, as if engaged by force?

Verse 37:
The Supreme Personality of Godhead said: It is lust only, Arjuna, which is born of contact with the material mode of passion and later transformed into wrath, and which is the all-devouring sinful enemy of this world.

Verse 38:
As fire is covered by smoke, as a mirror is covered by dust, or as the embryo is covered by the womb, the living entity is similarly covered by different degrees of this lust.

Verse 39:
Thus, a man's pure consciousness is covered by his eternal enemy in the form of lust, which is never satisfied and which burns like fire.

Verse 40:
The senses, the mind, and the intelligence are the sitting places of this lust. Through them, lust covers the real knowledge of the living entity and bewilders him.

Verse 41:
Therefore, O Arjuna, best of the Bharatas, in the very beginning curb this great symbol of sin (lust) by regulating the senses, and slay this destroyer of knowledge and self-realization.

Verse 42:
The working senses are superior to dull matter; mind is higher than the senses; intelligence is still higher than the mind; and he (the soul) is even higher than the intelligence.

Verse 43:
Thus knowing oneself to be transcendental to the material senses, mind, and intelligence, O mighty-armed Arjuna, one should steady the mind by deliberate spiritual intelligence (Krishna consciousness) and thus—by spiritual strength—conquer this insatiable enemy known as lust.
