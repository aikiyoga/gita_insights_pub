Chapter 6: Dhyana Yoga (The Yoga of Meditation)

Verse 1:
The Supreme Lord said: One who performs his prescribed duty without depending on the fruits of his actions is a sannyasi (renunciate) and a yogi, not he who is without fire (does no sacrifices) and without action.

Verse 2:
That which is called renunciation (sannyasa), know to be the same as yoga, O son of Pandu, for one can never become a yogi without giving up the desire for the fruits of actions.

Verse 3:
For a sage who is a candidate for the eightfold yoga system, work is said to be the means; and for one who has already attained to yoga, cessation of all material activities is said to be the means.

Verse 4:
A person is said to be elevated in yoga when, having renounced all material desires, he neither acts for sense gratification nor engages in fruitive activities.

Verse 5:
One must deliver himself with the help of his mind, and not degrade himself. The mind is the friend of the conditioned soul, and his enemy as well.

Verse 6:
For him who has conquered the mind, the mind is the best of friends; but for one who has failed to do so, his mind will remain the greatest enemy.

Verse 7:
For one who has conquered the mind, the Supersoul is already reached, for he has attained tranquility. To such a man, happiness and distress, heat and cold, honor and dishonor are all the same.

Verse 8:
A person is said to be established in self-realization and is called a yogi (or mystic) when he is fully satisfied by virtue of acquired knowledge and realization. Such a person is situated in transcendence and is self-controlled. He sees everything—whether it be pebbles, stones, or gold—as the same.

Verse 9:
A person is considered still further advanced when he regards honest well-wishers, affectionate benefactors, the neutral, mediators, the envious, friends and enemies, the pious and the sinners all with an equal mind.

Verse 10:
A transcendentalist should always engage in transcendental practices, remaining in a secluded place and constantly thinking of Me. He should live alone, with a controlled mind and body, and without desires and possessions.

Verse 11:
To practice yoga, one should go to a secluded place and should lay kusha grass on the ground and then cover it with a deerskin and a soft cloth. The seat should be neither too high nor too low and should be situated in a sacred place.

Verse 12:
There, the yogi should endeavor to control his mind, senses, and activities and should fix his mind on one point, practicing yoga for the purification of the heart.

Verse 13:
One should hold one's body, neck, and head erect in a straight line and stare steadily at the tip of the nose. Thus, with an unagitated, subdued mind, devoid of fear, completely free from sex life, one should meditate upon Me within the heart and make Me the ultimate goal of life.

Verse 14:
Thus practicing constant control of the body, mind, and activities, the mystic transcendentalist, his mind regulated, attains to the peace abiding in Me, culminating in liberation.

Verse 15:
Thus practicing constant control of the body, mind, and activities, the mystic transcendentalist, his mind regulated, attains to the peace abiding in Me, culminating in liberation.

Verse 16:
There is no possibility of one's becoming a yogi, O Arjuna, if one eats too much or eats too little, sleeps too much or does not sleep enough.

Verse 17:
He who is regulated in his habits of eating, sleeping, recreation, and work can mitigate all material pains by practicing the yoga system.

Verse 18:
When the yogi, by practice of yoga, disciplines his mental activities and becomes situated in transcendence—devoid of all material desires—he is said to be well established in yoga.

Verse 19:
As a lamp in a windless place does not waver, so the transcendentalist, whose mind is controlled, remains steady in his meditation on the transcendent self.

Verse 20:
In the stage of perfection called trance, or samadhi, one's mind is completely restrained from material mental activities by practice of yoga. This perfection is characterized by one's ability to see the self by the pure mind and to relish and rejoice in the self.

Verse 21:
In that joyous state, one is situated in boundless transcendental happiness, realized through transcendental senses. Established thus, one never departs from the truth.

Verse 22:
Upon gaining this, he thinks there is no greater gain. Being situated in such a position, he is never shaken, even in the midst of greatest difficulty.

Verse 23:
This indeed is actual freedom from all miseries arising from material contact.

Verse 24:
One should engage oneself in the practice of yoga with determination and faith and not be deviated from the path. One should abandon, without exception, all material desires born of mental speculation and thus control all the senses on all sides by the mind.

Verse 25:
Gradually, step by step, one should become situated in trance by means of intelligence sustained by full conviction, and thus the mind should be fixed on the self alone and should think of nothing else.

Verse 26:
From wherever the mind wanders due to its flickering and unsteady nature, one must certainly withdraw it and bring it back under the control of the self.

Verse 27:
The yogi whose mind is fixed on Me verily attains the highest perfection of transcendental happiness. He is beyond the mode of passion, he realizes his qualitative identity with the Supreme, and thus he is freed from all reactions to past deeds.

Verse 28:
Thus the self-controlled yogi, constantly engaged in yoga practice, becomes free from all material contamination and achieves the highest stage of perfect happiness in transcendental loving service to the Lord.

Verse 29:
A true yogi observes Me in all beings and also sees every being in Me. Indeed, the self-realized person sees Me, the same Supreme Lord, everywhere.

Verse 30:
For one who sees Me everywhere and sees everything in Me, I am never lost to him, nor is he ever lost to Me.

Verse 31:
Such a yogi, who engages in the worship of the Supersoul, knowing that I and the Supersoul are one, remains always in Me in all circumstances.

Verse 32:
He is a perfect yogi who, by comparison to his own self, sees the true equality of all beings, in both their happiness and distress, O Arjuna!

Verse 33:
Arjuna said: O Madhusudana, the system of yoga which You have summarized appears impractical and unendurable to me, for the mind is restless and unsteady.

Verse 34:
The mind is restless, turbulent, obstinate, and very strong, O Krishna, and to subdue it, I think, is more difficult than controlling the wind.

Verse 35:
Lord Shri Krishna said: O mighty-armed son of Kunti, it is undoubtedly very difficult to curb the restless mind, but it is possible by suitable practice and by detachment.

Verse 36:
For one whose mind is unbridled, self-realization is difficult work. But he whose mind is controlled and who strives by appropriate means is assured of success. That is My opinion.

Verse 37:
Arjuna said: What is the destination of the unsuccessful transcendentalist who in the beginning takes to the process of self-realization with faith but who does not persevere and gives up before reaching the perfect stage of yoga?

Verse 38:
O mighty-armed Krishna, does not such a man of spiritual aspirations, fallen from the path of Transcendence, perish like a riven cloud, with no position in any sphere?

Verse 39:
This is my doubt, O Krishna. I ask You to dispel it completely. But for You, no one is to be found who can destroy this doubt.

Verse 40:
The Supreme Personality of Godhead said: O son of Pritha, a transcendentalist engaged in auspicious activities does not meet with destruction in either this world or the spiritual world; one who does good, My friend, is never overcome by evil.

Verse 41:
The unsuccessful yogi, after many, many years of enjoyment on the planets of the pious living entities, is born into a family of righteous people, or into a wealthy aristocratic family.

Verse 42:
Or (if unsuccessful after long practice of yoga) he takes his birth in a family of transcendentalists who are surely great in wisdom. Undoubtedly, such a birth is rare in this world.

Verse 43:
On taking such a birth in a wealthy family or in a family of great yogis, he revives the divine consciousness of his previous life, and he again tries to make further progress in order to achieve complete success.

Verse 44:
By virtue of the divine consciousness of his previous life, he automatically becomes attracted to the yogic principles—even without seeking them. And when a person is actually seeking advanced yoga, he is always situated on the path of the wise, surpassing all scriptural rituals.

Verse 45:
And when the yogi engages himself with sincere endeavor in making further progress, being cleansed of all contaminations, he ultimately achieves the supreme goal after many, many years of practice.

Verse 46:
A yogi is greater than ascetics, greater than the empiricists, and greater than the fruitive workers. Therefore, O Arjuna, in all circumstances, be a yogi.

Verse 47:
And of all yogis, the one with great faith who always abides in Me, thinks of Me within himself, and renders transcendental loving service to Me—he is the most intimately united with Me in yoga and is the highest of all. This is My opinion.

